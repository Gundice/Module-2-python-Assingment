# Load the required library for reading CSV files
library(readr)

# Specify the path to the zip file
zip_file_path <- "C:/Users/Adeyemo Bolanle/employee_profile.zip"

# Unzip the folder
unzip(zip_file_path)

# Read the CSV file
employee_data <- read_csv("top_employee_details.csv")

# Display the data
print(employee_data)
